

<?php $__env->startSection('content'); ?>



    <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
        <li class="nav-item">
            <a href="<?php echo e(route('users.create')); ?>" class="nav-link active">
                <span>Create New</span>
            </a>
        </li>
    </ul>
    <div class="row ">
        <div class="col-md-12">
            <div class="main-card mb-3 card ">
                <div class="card-body table-responsive">

                    <?php if($records->count() > 0): ?>
                        <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0"
                            width="100%">
                            <thead>
                                <tr>
                                    <th class="th-sm">S.No</th>
                                    <th class="th-sm">Name</th>
                                    <th class="th-sm">E-mail</th>
                                    <th class="th-sm">Role</th>
                                    <th class="th-sm">Edit</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($row->name); ?></td>
                                        <td><?php echo e($row->email); ?></td>
                                        <td><?php echo e($row->role_id == 1 ? 'Admin' : 'Employee'); ?></td>

                                        <td><a href="<?php echo e(route('users.edit', $row->id)); ?>"
                                                class="mt-1 btn btn-success">Edit</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                            <tfoot>
                                <tr>
                                    <th class="th-sm">S.No</th>
                                    <th class="th-sm">Name</th>
                                    <th class="th-sm">E-mail</th>
                                    <th class="th-sm">Role</th>
                                    <th class="th-sm">Edit</th>
                                </tr>
                            </tfoot>
                        </table>

                        <?php echo e($records->links()); ?>

                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\tqm\resources\views/pages/users/index.blade.php ENDPATH**/ ?>