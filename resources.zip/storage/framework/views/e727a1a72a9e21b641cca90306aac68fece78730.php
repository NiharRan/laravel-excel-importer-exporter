<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-home icon-gradient bg-love-kiss">
                </i>
            </div>
            <div><?php echo e($title); ?>

                <div class="page-title-subheading"><?php echo e($sub_title); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\laragon\www\tqm\resources\views/partials/app-page-header.blade.php ENDPATH**/ ?>