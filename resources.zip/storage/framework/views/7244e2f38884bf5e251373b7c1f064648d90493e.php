

<?php $__env->startSection('content'); ?>



    <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
        <li class="nav-item">
            <a href="<?php echo e(route('users.index')); ?>" class="nav-link active">
                <span>Back</span>
            </a>
        </li>
    </ul>
    <div class="row ">
        <div class="col-md-12">
            <div class="main-card mb-3 card ">
                <div class="card-body">

                    <form action="<?php echo e(route('users.update', $user->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo method_field('PUT'); ?>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="position-relative form-group">
                                    <label for="name"
                                        class=""> 
                                        <strong>  Name :</strong>
                                    </label>
                                        <input name="name"  value="<?php echo e($user->name); ?>"
                                        id="name" placeholder="User Name" 
                                        type="text" class="form-control">
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="position-relative form-group">
                                    <label for="email"
                                        class="">  <strong>Email :</strong></label>
                                        <input 
                                        name="email"  value="<?php echo e($user->email); ?>"
                                        id="email" placeholder="User Email"
                                        type="email" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-4">

                                <div class="position-relative form-group">
                                    <label for="role_id"
                                        class=""><strong>Role: </strong></label>
                                        <select id="role_id" 
                                        name="role_id" class="custom-select">
                                        <option value="">Select Role</option>
                                        <option value="1" <?php echo e($user->role_id == 1 ? "selected" : ''); ?>>Admin</option>
                                        <option value="2" <?php echo e($user->role_id == 2 ? "selected" : ''); ?>>Employee</option>
                                        </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="position-relative form-group">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\tqm\resources\views/pages/users/edit.blade.php ENDPATH**/ ?>